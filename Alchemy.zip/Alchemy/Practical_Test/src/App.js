import React from 'react';
import './App.css';

class App extends React.Component {

  state = {
    imageUrl: ""
  }

  componentDidMount() {
    this.refresh();
  }

  refresh = () => {
    fetch('https://dog.ceo/api/breeds/image/random')
    .then( response => response.json() )
    .then( data => this.setState({ imageUrl: data.message }) )
  }

  render() {
    return (
      <div className="App">
        <div>
        <button onClick={this.refresh} class="btn btn-primary btn-lg" type="button">Reset Image</button>
        </div>
        <br></br>
        <div>
          <img className="image"  class="rounded"  src={this.state.imageUrl} />
        </div>
      </div>
    );
  }
}

export default App;
